import { PasswordGenerator } from '../utils/passwordGenerator.js';
class PopupController {
    constructor() {
        this.passwordGenerator = new PasswordGenerator();
        this.initialize();
    }
    initialize() {
        document.addEventListener('DOMContentLoaded', () => {
            this.passwordOutput = document.getElementById('passwordOutput');
            this.btn8 = document.getElementById('btn8');
            this.btn16 = document.getElementById('btn16');
            this.btn32 = document.getElementById('btn32');
            this.btn8?.addEventListener('click', () => this.generateAndCopy(8));
            this.btn16?.addEventListener('click', () => this.generateAndCopy(16));
            this.btn32?.addEventListener('click', () => this.generateAndCopy(32));
        });
    }
    async generateAndCopy(length) {
        if (this.passwordOutput) {
            const password = this.passwordGenerator.generate(length);
            this.passwordOutput.value = password;
            await navigator.clipboard.writeText(password);
        }
    }
}
new PopupController();
//# sourceMappingURL=popup.js.map