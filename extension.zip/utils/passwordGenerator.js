export class PasswordGenerator {
    constructor() {
        this.allowedChars = {
            lowercase: 'abcdefhjkmnpqrstuvwxyz',
            uppercase: 'ABCDEFHJKPQR',
            numbers: '123456789',
            special: '@'
        };
    }
    generate(length) {
        let charset = this.allowedChars.lowercase +
            this.allowedChars.uppercase +
            this.allowedChars.numbers +
            this.allowedChars.special;
        let password = '';
        password += this.getRandomChar(this.allowedChars.lowercase);
        password += this.getRandomChar(this.allowedChars.uppercase);
        password += this.getRandomChar(this.allowedChars.numbers);
        password += this.getRandomChar(this.allowedChars.special);
        for (let i = 4; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * charset.length);
            password += charset[randomIndex];
        }
        return this.shuffleString(password);
    }
    getRandomChar(charset) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        return charset[randomIndex];
    }
    shuffleString(str) {
        const array = str.split('');
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array.join('');
    }
}
//# sourceMappingURL=passwordGenerator.js.map