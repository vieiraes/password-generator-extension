export declare class PasswordGenerator {
    private readonly allowedChars;
    generate(length: number): string;
    private getRandomChar;
    private shuffleString;
}
